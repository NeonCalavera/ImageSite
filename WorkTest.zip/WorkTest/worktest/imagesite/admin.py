from django.contrib import admin
from .models import SiteUser, Image, Following, Like

admin.site.register(SiteUser)
admin.site.register(Image)
admin.site.register(Following)
admin.site.register(Like)
