from django.apps import AppConfig


class ImagesiteConfig(AppConfig):
    name = 'imagesite'
