from django import forms

class UploadImageForm(forms.Form):
    caption = forms.CharField(max_length=200)
    upload = forms.ImageField()