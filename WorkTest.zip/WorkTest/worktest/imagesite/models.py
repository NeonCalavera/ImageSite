from django.db import models
from django.forms import ModelForm

class SiteUser(models.Model):
    useremail = models.CharField(max_length=50)
    password = models.CharField(max_length=20)
    username = models.CharField(max_length=20)
	
    def __str__(self):
        return self.username

def user_directory_path(instance, filename):
      
      return 'user_{0}/{1}'.format(instance.user.id, filename)

class Image(models.Model):
    
    caption = models.CharField(max_length=100)
    user = models.ForeignKey('SiteUser', on_delete=models.CASCADE)
    uploaddatetime = models.DateTimeField()
    upload = models.ImageField(upload_to=user_directory_path)

    def calculateLikes(self):
        return Like.objects.filter(image = self).count()

    likes = property(calculateLikes)
	
    def __str__(self):
        return self.caption

  

class Following(models.Model):
    User1 = models.ForeignKey('SiteUser', related_name='user1',  on_delete=models.CASCADE)
    User2 = models.ForeignKey('SiteUser', related_name='user2',  on_delete=models.CASCADE)
    
	
class Like(models.Model):
    image = models.ForeignKey('Image', on_delete=models.CASCADE)
    user = models.ForeignKey('SiteUser', on_delete=models.CASCADE)



