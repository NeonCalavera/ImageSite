from django.urls import path


from . import views

app_name = "imagesite"

urlpatterns = [
    path('', views.index, name='index'),
    path('Home/', views.Home, name='Home'),
    path('Created/', views.Create, name='Create'),
    path('Upload/', views.Upload, name='Upload'),
    path('TopPosts/', views.AllPosts, name='AllPosts'),
    path('AllUsers/', views.AllUsers, name='AllUsers'),
    
]
