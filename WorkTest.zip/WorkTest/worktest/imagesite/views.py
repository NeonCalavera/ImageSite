from django.shortcuts import render
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.shortcuts import get_object_or_404, render
from .models import SiteUser, Image, Following, Like
from .forms import UploadImageForm
import datetime
from django.utils import timezone
import re
from passlib.hash import sha256_crypt

def index(request):
  
  if 'logout' in request.POST:
    return render(request, 'imagesite/index.html', {'logout': True})
  else:
    return render(request, 'imagesite/index.html')

def Home(request):
  
  if 'login' in request.POST:
      print('login')
      useremail=request.POST['useremail'].strip()
      password=request.POST['password'].strip()
      username=request.POST['username'].strip()
      usercheck=SiteUser.objects.filter(useremail=useremail).filter(username=username)
      if usercheck.count() == 0:     
        return render(request, 'imagesite/index.html',{'bad_login': True})
      else:
        User = usercheck[0]
        
        

        if sha256_crypt.verify(password, User.password):
          print('gg')
          
        else:
          
          print('Password is incorrect')
          return render(request, 'imagesite/index.html',{'bad_login': True})

  elif 'uploadf' in request.POST:
    Userid = request.POST['Userid']   
    User = get_object_or_404(SiteUser, pk=Userid)
    Upload = request.FILES['upload']
    caption = request.POST['caption']
    image = Image.objects.create(user=User, caption=caption, upload=Upload, uploaddatetime=timezone.now())
    image.save()
    
  elif 'home' in request.POST:
    Userid = request.POST['Userid']   
    User = get_object_or_404(SiteUser, pk=Userid)    

  elif 'like' in request.POST:
    
    Userid = request.POST['Userid']   
    User = get_object_or_404(SiteUser, pk=Userid)
    for key in request.POST.keys():    
        imageid = key
    image=get_object_or_404(Image, pk=imageid)
    check = Like.objects.filter(user = User).filter(image = image)
    if len(check) == 0:
      like = Like.objects.create(user=User, image=image)

    else:
      Like.objects.filter(user = User).filter(image = image).delete()
    

  else: 
    return HttpResponseRedirect('/Imagesite/')

  

  PostListQ = Image.objects.order_by('uploaddatetime')
  PostList=list(PostListQ)
  PostList.sort(key=lambda x: x.uploaddatetime, reverse = True)
  FollowedUserInstanceList = Following.objects.filter(User1=User) 
  FollowedUserList=[]
  for following in FollowedUserInstanceList:    
    FollowedUserList.append(following.User2)
  FollowedPostList=[]
  for post in PostList:
    for user2 in FollowedUserList:
      if post.user == user2:
        FollowedPostList.append(post)
  LikedPostInstanceList = Like.objects.filter(user=User)
  LikedPostList = []      
  for like in LikedPostInstanceList:
    LikedPostList.append(like.image)    
  
  ImageLikeCount = {}
  alllikes = []
  alllikes =  Like.objects.filter(pk=not None)
  for image in PostList:
    x=0
    for like in alllikes:
      if image == like.image:
        x += 1  
    ImageLikeCount.update({image: x})
  return render(request, 'imagesite/home.html', {'User' : User, 'FollowedPostList' : FollowedPostList, 'LikedPostList' : LikedPostList, 'ImageLikeCount' : ImageLikeCount})

def Create(request):

  useremail=request.POST['useremail'].strip()
  password=request.POST['password'].strip()
  username=request.POST['username'].strip()
    
  
  

  usercheck=SiteUser.objects.filter(useremail=useremail)
  if usercheck.count() != 0:     
    return render(request, 'imagesite/index.html',{'bad_login': True})
  else:
    
    passwordenc = sha256_crypt.encrypt(password)
    
    User = SiteUser(None, useremail, passwordenc, username)
    User.save()

    return render(request, 'imagesite/Create.html', {'User' : User})

def Upload(request): 
  
  Userid = request.POST['Userid']   
  User = SiteUser.objects.filter(id=Userid)[0]
  form = UploadImageForm(request.POST, request.FILES)
  
    
    

  return render(request, 'imagesite/Upload.html', {'User' : User, 'form' : form})

def AllPosts(request): 
  Userid = request.POST['Userid']   
  User = SiteUser.objects.filter(id=Userid)[0]
  
  if 'like' in request.POST:
    
    
    for key in request.POST.keys():    
        imageid = key
    image=get_object_or_404(Image, pk=imageid)
    check = Like.objects.filter(user = User).filter(image = image)
    if len(check) == 0:
      like = Like.objects.create(user=User, image=image)

    else:
      Like.objects.filter(user = User).filter(image = image).delete()

  AllByLikesQ = Image.objects.order_by('uploaddatetime')
  AllByLikes = list(AllByLikesQ)
  AllByLikes.sort(key=lambda x: x.likes, reverse = True)
  LikedPostInstanceList = Like.objects.filter(user=User)
  LikedPostList = []      
  for like in LikedPostInstanceList:
    LikedPostList.append(like.image)   
  return render(request, 'imagesite/Allposts.html', {'User' : User, 'AllByLikes' : AllByLikes, 'LikedPostList' : LikedPostList})

def AllUsers(request): 
  Userid = request.POST['Userid']   
  User = get_object_or_404(SiteUser, pk=Userid)

  if 'follow' in request.POST:
    print("follow")
    for key in request.POST.keys():    
        user2id = key
    user2=get_object_or_404(SiteUser, pk=user2id)
    check = Following.objects.filter(User1 = User).filter(User2 = user2)
    if len(check) == 0:
      following = Following.objects.create(User1=User, User2=user2)

  if 'unfollow' in request.POST:
    for key in request.POST.keys():    
        user2id = key
    user2=get_object_or_404(SiteUser, pk=user2id)
    Following.objects.filter(User1 = User).filter(User2 = user2).delete()

  UserListQ = SiteUser.objects.order_by('id')
  UserList=list(UserListQ)
  FollowedUserInstanceList = Following.objects.filter(User1=User) 
  FollowedUserList=[]
  for following in FollowedUserInstanceList:    
    FollowedUserList.append(following.User2)
  
  for check in reversed(UserList):
    for check2 in FollowedUserList:
      if check == check2:
        UserList.remove(check)
  return render(request, 'imagesite/Allusers.html', {'User' : User, 'UserList' : UserList, 'FollowedUserList' : FollowedUserList})
       
  